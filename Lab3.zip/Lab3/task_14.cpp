#include <iostream>
using namespace std;

int main() {
	
	int total_income =0;
	int classA_price = 15, classB_price = 12, classC_price = 9;
	int classA_tickets = 0, classB_tickets = 0, classC_tickets = 0;

	cout << "Class A tickets sold: ";
	cin >> classA_tickets;
	cout << "Class B tickets sold: ";
	cin >> classB_tickets;
	cout << "Class C tickets sold: ";
	cin >> classC_tickets;

	total_income = (classA_tickets*classA_price)+(classB_tickets * classB_price)+(classC_tickets * classC_price);
	cout << "Total Income: "<<total_income<<endl;


	return 0;
}