#include <iostream>
using namespace std;

int main() {
	
	float length = 0,width=0,perimeter=0, area = 0;

	cout << "Length: ";
	cin >> length;
	cout << "Width: ";
	cin >> width;
	
	area = width*length;
	perimeter = 2*(width + length);

	cout << "Area: "<<area;
	cout << "\n Perimeter: " << perimeter;


	return 0;
}