#include <iostream>
using namespace std;

int main() {
	
	int chem = 0,math=0,phy=0;

	cout << "Chemistry: ";
	cin >> chem;
	cout << "Math: ";
	cin >> math;
	cout << "Physics: ";
	cin >> phy;


	cout << "------------------------------------------------------------------------\n";
	cout << "MATHS\tCHEMISTRY\tPHYSICS\t\tTOTAL\n";
	cout << math << "\t" << chem << "\t\t" << phy << "\t\t" << math + chem + phy << endl;
	cout << "------------------------------------------------------------------------\n";
	return 0;
}