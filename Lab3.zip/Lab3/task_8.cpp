#include <iostream>
using namespace std;

int main() {
	
	float radius = 0, area = 0;

	cout << "Radius: ";
	cin >> radius;
	area = 3.141592653 * (radius * radius);
	cout << "Area: "<<area;


	return 0;
}