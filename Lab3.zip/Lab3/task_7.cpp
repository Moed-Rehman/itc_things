#include <iostream>
using namespace std;

int main() {
	
	float t1 = 0, t2 = 0, t3 = 0, t4 = 0, t5 = 0;
	
	cout << "Test Score 1: ";
	cin >> t1;
	cout << "Test Score 2: ";
	cin >> t2;
	cout << "Test Score 3: ";
	cin >> t3;
	cout << "Test Score 4: ";
	cin >> t4;
	cout << "Test Score 5: ";
	cin >> t5;

	cout << "Average of all the Test Scores: "<<(t1+t2+t3+t4+t5)/5;

	return 0;
}