#include <iostream>
using namespace std;

int main() {
	
	int wheat_q = 0,rice_q=0,sugar_q=0;
	int wheat_p = 0, rice_p = 0, sugar_p = 0;

	cout << "price of wheat: ";
	cin >> wheat_p;
	cout << "quantity of wheat: ";
	cin >> wheat_q;
	
	cout << "price of rice: ";
	cin >> rice_p;
	cout << "quantity of rice: ";
	cin >> rice_q;

	cout << "price of sugar: ";
	cin >> sugar_p;
	cout << "quantity of sugar: ";
	cin >> sugar_q;

	cout << "---------------------------------\n";
	cout << "Value of Wheat: " << wheat_p * wheat_q;
	cout << "\nValue of Rice: " << rice_p * rice_q;
	cout << "\nValue of Sugar: " << sugar_p * sugar_q;
	cout << "\n---------------------------------\n";

	return 0;
}