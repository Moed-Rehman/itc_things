#include <iostream>
using namespace std;

int main() {
	
	int fuel =0,rent=0,bill=0;
	int total = 0;

	cout << "Fuel: ";
	cin >> fuel;
	cout << "Rent: ";
	cin >> rent;
	cout << "Bill: ";
	cin >> bill;

	total = fuel + rent + bill;
	cout << "----------------------------------------\n";
	cout << "FUEL:\t" << fuel<<endl;
	cout << "RENT:\t" << rent << endl;
	cout << "BILLS:\t" << bill << endl;
	cout << "TOTAL:\t" << total << endl;
	cout << "----------------------------------------\n";

	


	return 0;
}