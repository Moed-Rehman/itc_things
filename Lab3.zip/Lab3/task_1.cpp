#include <iostream>
using namespace std;

int main() {

	int input = 0;

	cout << "Enter value of input: ";
	cin >> input;
	cout << "input: "<<input;


	return 0;
}