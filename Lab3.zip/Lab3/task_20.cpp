#include <iostream>
using namespace std;

int main() {
	
	float Gmeal_cost =50, Smeal_cost = 30, Fmeal_cost = 20;
	int Gmeal_sold = 0, Smeal_sold = 0, Fmeal_sold = 0;

	cout << "Gourmet meals sold: ";
	cin >> Gmeal_sold;
	cout << "Standard meals sold: ";
	cin >> Smeal_sold;
	cout << "Fast meals sold: ";
	cin >> Fmeal_sold;

	float total_revenue = (Gmeal_sold* Gmeal_cost) + (Smeal_sold * Smeal_cost) + (Fmeal_sold * Fmeal_cost);

	cout << "Total revenue earned: " << total_revenue << endl;



	return 0;
}