#include <iostream>
using namespace std;

int main() {
	
	double radius= 0, height = 0;

	cout << "Enter radius of cylinder: ";
	cin >> radius;
	cout << "Enter height of cylinder: ";
	cin >> height;
	
	double volume = 3.141592653 *(radius* radius)*height;
	float surface_area = 2* 3.141592653 * radius *(radius+height);

	cout << "Volume of the cylinder is: " << volume << endl;
	cout << "Surface Area of the cylinder is: " << surface_area << endl;


	return 0;
}