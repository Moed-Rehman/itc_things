#include <iostream>
using namespace std;

int main() {
	
	float Bcourse_cost =500, Acourse_cost = 1000, Pcourse_cost = 2000;
	float discount_percent = 15;

	int Bcourse_sold = 0, Acourse_sold = 0, Pcourse_sold = 0;

	cout << "Number of Basic courses to enroll in: ";
	cin >> Bcourse_sold;
	cout << "Number of Advanced courses to enroll in: ";
	cin >> Acourse_sold;
	cout << "Number of Professional courses to enroll in: ";
	cin >> Pcourse_sold;


	float total_cost = (Bcourse_sold * Bcourse_cost) + (Acourse_sold * Acourse_cost) + (Pcourse_sold * Pcourse_cost);
	float price_discounted = (discount_percent*total_cost) /100 ;
	float final_price = total_cost - price_discounted;

	cout << "Price without " << discount_percent << "% discount" << ": " << total_cost << endl;
	cout << "Final price with " << discount_percent << "% discount" << ": " << final_price;


	return 0;
}