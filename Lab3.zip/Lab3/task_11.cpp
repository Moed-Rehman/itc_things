#include <iostream>
using namespace std;

int main() {
	
	int minutes = 0,hours=0;

	cout << "Hours: ";
	cin >> hours;
	cout << "Minutes: ";
	cin >> minutes;

	minutes = (hours*60)+minutes;

	cout << "Total Minutes: "<<minutes;
	

	return 0;
}