#include <iostream>
using namespace std;

int main() {
	
	float weight= 0, height = 0;

	cout << "Enter weight in kg: ";
	cin >> weight;
	cout << "Enter height in m: ";
	cin >> height;
	
	float BMI = weight / (height* height);
	cout << "BMI: "<<BMI;
	


	return 0;
}