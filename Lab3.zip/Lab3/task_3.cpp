#include <iostream>
using namespace std;

int main() {

	int x = 5;
	cout << "The value of x is " << x;

	return 0;
}