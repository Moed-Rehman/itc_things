#include <iostream>
using namespace std;

int main() {
	
	int minutes = 0,hours=0;

	cout << "Minutes: ";
	cin >> minutes;

	hours = minutes / 60;
	minutes = minutes % 60;

	cout << hours<<" hours, "<<minutes<<" minutes\n";
	

	return 0;
}