#include <iostream>
using namespace std;

int main() {
	
	int cookies_in_bag = 40,servings_in_bag=10,calorie_per_serving=300;
	float calories_per_cookie = calorie_per_serving / (cookies_in_bag / servings_in_bag);

	int num_cookies_ate = 0;

	cout << "cookies consumed: ";
	cin >> num_cookies_ate;

	cout << "calories consumed: "<<num_cookies_ate*calories_per_cookie;


	return 0;
}