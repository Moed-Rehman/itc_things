#include <iostream>
using namespace std;

int main() {

	cout << "\t\t Hello, Class!" <<"\n\t Welcome to the ITC-Lab Week-03" << endl;

	return 0;
}