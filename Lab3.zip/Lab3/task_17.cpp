#include <iostream>
using namespace std;

int main() {
	
	float speed = 20;
	float time = 10;
	float distance = speed*time;

	cout << distance << endl;

	return 0;
}