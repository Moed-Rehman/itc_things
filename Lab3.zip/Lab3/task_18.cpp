#include <iostream>
using namespace std;

int main() {
	
	float num_orig = 0;
	
	cout << "input:";
	cin >> num_orig;

	float num1 = num_orig +1, num2 = num_orig + 2, num3 = num_orig + 3, num4 = num_orig + 4, num5 = num_orig + 5;
	float sqr_orig=(num_orig* num_orig),sqr1 = (num1 * num1), sqr2 = (num2 * num2), sqr3 = (num3 * num3), sqr4 = (num4 * num4), sqr5 = (num5 * num5);
	float cb_orig = (num_orig * num_orig * num_orig), cb1 = (num1 * num1 * num1), cb2 = (num2 * num2 * num2), cb3 = (num3 * num3 * num3), cb4 = (num4 * num4 * num4), cb5 = (num5 * num5 * num5);

	cout << "No\tSquare\tCube\n";
	cout << num_orig<<"\t" << sqr_orig << "\t" << cb_orig<<endl;
	cout << num1 << "\t" << sqr1 << "\t" << cb1<<endl;
	cout << num2 << "\t" << sqr2 << "\t" << cb2<<endl;
	cout << num3 << "\t" << sqr3 << "\t" << cb3 << endl;
	cout << num4 << "\t" << sqr4 << "\t" << cb4 << endl;
	cout << num5 << "\t" << sqr5 << "\t" << cb5 << endl;



	return 0;
}