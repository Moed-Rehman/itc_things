#include <iostream>
using namespace std;

int main() {
	
	int gallon_fuel =0,miles_travelled=0;
	float mpg = 0;

	cout << "Fuel in Gallons in the car: ";
	cin >> gallon_fuel;
	cout << "Miles traveled by the car: ";
	cin >> miles_travelled;

	mpg = miles_travelled / gallon_fuel;

	cout << "The car travelled "<< mpg <<" miles per 1 gallon of fuel\n";



	return 0;
}